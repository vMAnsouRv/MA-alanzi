# Liar's Anti-Cheat

Welcome to the **Liar's Bar Anti-Cheat Mod**! This is an **anti-cheat** mod 
designed to enhance the integrity and fairness of the 
[Liar's Bar](https://store.steampowered.com/app/3097560/Liars_Bar/) game by 
preventing and mitigating the most common cheats.

As a fresh, brand-new game that has just recently been released, Liar's Bar is 
still in the process of refining its security measures. The game developers are 
working diligently to address these issues and enhance the overall gameplay 
experience.

However, with the game's current P2P setup, it is unfortunately easy for 
players to cheat. This mod aims to address these issues by providing robust 
anti-cheat mechanisms.


# Features

- **Players' Cards Obfuscation:** 
Prevent cheaters from seeing other players' cards by obfuscating everyone's 
cards to 5 jokers.

- **Thrown Cards Obfuscation:** 
Prevent cheaters from seeing the cards that got played onto the table by 
obfuscating the played cards into all joker cards.

- **Bullet Position Obfuscation:** 
Prevent cheaters from seeing your (host) bullet position by obfuscating your 
bullet position to the last chamber and only revealing your real bullet 
position when you are about to die.

- **Auto-Kick for Cheating:** 
  - Auto-kick cheaters attempting to play cards that they don't have in their hand.
  - Auto-kick cheaters attempting to change their bullet positions mid-game.
  - Auto-kick cheaters trying to place their bullet into an invalid revolver chamber.
  - Auto-kick cheaters that illegally modify their revolver shot counter (e.g., decrease the shot counter).
  - Auto-kick cheaters (or modders) that modify the chat messages in an illegal way (e.g., impersonating someone else, hiding their player name, changing the name color, etc.).


# Installation

1. Install **BepInEx** (see [BepInEx Installation Guide](https://docs.bepinex.dev/articles/user_guide/installation/index.html))

2. Launch **Liar's Bar** _once_ with **BepInEx** installed to generate necessary mod folders and files

3. Navigate to your **Liar's Bar** game directory and go to `./BepInEx/plugins`
    - The `BepInEx` and `plugins` folder should have been generated in the previous step
    - **Example:** `C:\Program Files\Steam\steamapps\common\Liar's Bar\BepInEx\plugins`

4. Download the Anti-Cheat mod from the [Nexus Mods](https://next.nexusmods.com/profile/Tyzeron/mods)

5. Copy the downloaded **DLL file** (ex. `LiarsAntiCheat.dll`) to the `plugins` folder

6. Launch the **Liar's Bar** game and enjoy your new Anti-Cheat mod :)


# Host-Only

Please note that this anti-cheat mod works only if you are the host of the 
lobby and hosting the game. If you join someone else's lobby, none of the 
anti-cheat features will work, as it all depends on having server authority.

However, you can still join other players' lobbies just fine, and it won't have 
any impact on your ability to play the game.


# Contact

I am primarily active on Discord, but my **DMs are closed**. The most effective 
way to get in touch with me is via a Discord Server **support ticket**.

To find the most up-to-date invite link to the Discord server, please visit my 
**Twitter/X** profile: [@Tyzeron](https://x.com/tyzeron).

I serve as a `System Administrator` on the Discord server and am highly active 
there. I have decided to take this approach as it allows me to keep my focus on 
mod development, without the added responsibility of owning and maintaining my 
own Discord server.
